package com.luxury.sede.dto;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.sede.model.Sede;

public record SedeResponse(Long id, String nombre, String ciudad, String direccion, EstadoRegistro estado) {

	public static SedeResponse from(Sede sede) {
		return new SedeResponse(sede.getId(), sede.getNombre(), sede.getCiudad(), sede.getDireccion(), sede.getEstado());
	}
}
