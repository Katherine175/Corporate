package com.luxury.sede.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.sede.dto.SedeRequest;
import com.luxury.sede.dto.SedeResponse;
import com.luxury.sede.model.Sede;
import com.luxury.sede.repository.SedeRepository;

@Service
public class SedeService {

	private final SedeRepository sedeRepository;

	public SedeService(SedeRepository sedeRepository) {
		this.sedeRepository = sedeRepository;
	}

	@Transactional(readOnly = true)
	public List<SedeResponse> listar() {
		return sedeRepository.findAll().stream().map(SedeResponse::from).toList();
	}

	@Transactional(readOnly = true)
	public SedeResponse obtener(Long id) {
		return SedeResponse.from(buscar(id));
	}

	@Transactional
	public SedeResponse crear(SedeRequest request) {
		Sede sede = new Sede();
		aplicar(sede, request);
		return SedeResponse.from(sedeRepository.save(sede));
	}

	@Transactional
	public SedeResponse actualizar(Long id, SedeRequest request) {
		Sede sede = buscar(id);
		aplicar(sede, request);
		return SedeResponse.from(sede);
	}

	@Transactional
	public void eliminar(Long id) {
		Sede sede = buscar(id);
		sede.setEstado(EstadoRegistro.INACTIVO);
	}

	public Sede buscar(Long id) {
		return sedeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Sede no encontrada"));
	}

	private void aplicar(Sede sede, SedeRequest request) {
		sede.setNombre(request.nombre());
		sede.setCiudad(request.ciudad());
		sede.setDireccion(request.direccion());
		sede.setEstado(request.estado() == null ? EstadoRegistro.ACTIVO : request.estado());
	}
}
