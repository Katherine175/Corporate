package com.luxury.sede.dto;

import com.luxury.common.enums.EstadoRegistro;

import jakarta.validation.constraints.NotBlank;

public record SedeRequest(
		@NotBlank String nombre,
		@NotBlank String ciudad,
		@NotBlank String direccion,
		EstadoRegistro estado) {
}
