package com.luxury.security.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.usuario.model.Usuario;
import com.luxury.usuario.repository.UsuarioRepository;

@Service
public class AuthenticatedUserService {

	private final UsuarioRepository usuarioRepository;

	public AuthenticatedUserService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	public Usuario actual() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null || authentication.getName() == null) {
			throw new ResourceNotFoundException("Usuario autenticado no encontrado");
		}
		return usuarioRepository.findByEmail(authentication.getName())
				.orElseThrow(() -> new ResourceNotFoundException("Usuario autenticado no encontrado"));
	}
}
