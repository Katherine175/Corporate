package com.luxury.security.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.usuario.model.Usuario;
import com.luxury.usuario.repository.UsuarioRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	private final UsuarioRepository usuarioRepository;

	public UserDetailsServiceImpl(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	@Override
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Usuario usuario = usuarioRepository.findByEmail(email)
				.orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));
		Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		usuario.getUsuarioRoles().forEach(usuarioRol -> {
			authorities.add(new SimpleGrantedAuthority("ROLE_" + usuarioRol.getRol().getNombre()));
			usuarioRol.getRol().getRolPermisos().forEach(rolPermiso ->
					authorities.add(new SimpleGrantedAuthority(rolPermiso.getPermiso().getNombre())));
		});
		boolean enabled = usuario.getEstado() == EstadoRegistro.ACTIVO;
		return User.withUsername(usuario.getEmail())
				.password(usuario.getPassword())
				.authorities(authorities)
				.disabled(!enabled)
				.build();
	}
}
