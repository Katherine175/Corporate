package com.luxury.umbral.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.recurso.service.TipoRecursoService;
import com.luxury.sede.service.SedeService;
import com.luxury.umbral.dto.UmbralRequest;
import com.luxury.umbral.dto.UmbralResponse;
import com.luxury.umbral.model.Umbral;
import com.luxury.umbral.repository.UmbralRepository;

@Service
public class UmbralService {

	private final UmbralRepository umbralRepository;
	private final SedeService sedeService;
	private final TipoRecursoService tipoRecursoService;

	public UmbralService(UmbralRepository umbralRepository, SedeService sedeService, TipoRecursoService tipoRecursoService) {
		this.umbralRepository = umbralRepository;
		this.sedeService = sedeService;
		this.tipoRecursoService = tipoRecursoService;
	}

	@Transactional(readOnly = true)
	public List<UmbralResponse> listar() {
		return umbralRepository.findAll().stream().map(UmbralResponse::from).toList();
	}

	@Transactional
	public UmbralResponse crear(UmbralRequest request) {
		Umbral umbral = new Umbral();
		aplicar(umbral, request);
		return UmbralResponse.from(umbralRepository.save(umbral));
	}

	@Transactional
	public UmbralResponse actualizar(Long id, UmbralRequest request) {
		Umbral umbral = buscar(id);
		aplicar(umbral, request);
		return UmbralResponse.from(umbral);
	}

	@Transactional
	public void eliminar(Long id) {
		Umbral umbral = buscar(id);
		umbral.setEstado(EstadoRegistro.INACTIVO);
	}

	public Umbral buscar(Long id) {
		return umbralRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Umbral no encontrado"));
	}

	public Umbral buscarVigente(Long sedeId, Long tipoRecursoId, LocalDate fecha) {
		return umbralRepository.findVigente(sedeId, tipoRecursoId, fecha, EstadoRegistro.ACTIVO).orElse(null);
	}

	private void aplicar(Umbral umbral, UmbralRequest request) {
		umbral.setSede(sedeService.buscar(request.sedeId()));
		umbral.setTipoRecurso(tipoRecursoService.buscar(request.tipoRecursoId()));
		umbral.setLimiteConsumo(request.limiteConsumo());
		umbral.setLimitePresupuestoPen(request.limitePresupuestoPen());
		umbral.setFechaInicio(request.fechaInicio());
		umbral.setFechaFin(request.fechaFin());
		umbral.setEstado(request.estado() == null ? EstadoRegistro.ACTIVO : request.estado());
	}
}
