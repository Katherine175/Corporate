package com.luxury.umbral.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record UmbralRequest(
		@NotNull Long sedeId,
		@NotNull Long tipoRecursoId,
		@PositiveOrZero BigDecimal limiteConsumo,
		@PositiveOrZero BigDecimal limitePresupuestoPen,
		@NotNull LocalDate fechaInicio,
		LocalDate fechaFin,
		EstadoRegistro estado) {
}
