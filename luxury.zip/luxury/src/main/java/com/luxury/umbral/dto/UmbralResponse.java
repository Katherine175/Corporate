package com.luxury.umbral.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.umbral.model.Umbral;

public record UmbralResponse(
		Long id,
		Long sedeId,
		String sede,
		Long tipoRecursoId,
		String tipoRecurso,
		BigDecimal limiteConsumo,
		BigDecimal limitePresupuestoPen,
		LocalDate fechaInicio,
		LocalDate fechaFin,
		EstadoRegistro estado) {

	public static UmbralResponse from(Umbral umbral) {
		return new UmbralResponse(
				umbral.getId(),
				umbral.getSede().getId(),
				umbral.getSede().getNombre(),
				umbral.getTipoRecurso().getId(),
				umbral.getTipoRecurso().getNombre(),
				umbral.getLimiteConsumo(),
				umbral.getLimitePresupuestoPen(),
				umbral.getFechaInicio(),
				umbral.getFechaFin(),
				umbral.getEstado());
	}
}
