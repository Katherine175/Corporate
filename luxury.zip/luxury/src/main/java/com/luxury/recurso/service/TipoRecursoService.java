package com.luxury.recurso.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.recurso.dto.TipoRecursoRequest;
import com.luxury.recurso.dto.TipoRecursoResponse;
import com.luxury.recurso.model.TipoRecurso;
import com.luxury.recurso.repository.TipoRecursoRepository;

@Service
public class TipoRecursoService {

	private final TipoRecursoRepository tipoRecursoRepository;

	public TipoRecursoService(TipoRecursoRepository tipoRecursoRepository) {
		this.tipoRecursoRepository = tipoRecursoRepository;
	}

	@Transactional(readOnly = true)
	public List<TipoRecursoResponse> listar() {
		return tipoRecursoRepository.findAll().stream().map(TipoRecursoResponse::from).toList();
	}

	@Transactional
	public TipoRecursoResponse crear(TipoRecursoRequest request) {
		TipoRecurso tipo = new TipoRecurso();
		aplicar(tipo, request);
		return TipoRecursoResponse.from(tipoRecursoRepository.save(tipo));
	}

	@Transactional
	public TipoRecursoResponse actualizar(Long id, TipoRecursoRequest request) {
		TipoRecurso tipo = buscar(id);
		aplicar(tipo, request);
		return TipoRecursoResponse.from(tipo);
	}

	@Transactional
	public void eliminar(Long id) {
		tipoRecursoRepository.delete(buscar(id));
	}

	public TipoRecurso buscar(Long id) {
		return tipoRecursoRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Tipo de recurso no encontrado"));
	}

	private void aplicar(TipoRecurso tipo, TipoRecursoRequest request) {
		tipo.setNombre(request.nombre());
		tipo.setUnidadMedida(request.unidadMedida());
	}
}
