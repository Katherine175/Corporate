package com.luxury.recurso.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TipoRecursoForm {

	@NotBlank
	private String nombre;

	@NotBlank
	private String unidadMedida;

	public TipoRecursoRequest toRequest() {
		return new TipoRecursoRequest(nombre, unidadMedida);
	}
}
