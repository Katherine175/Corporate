package com.luxury.recurso.dto;

import com.luxury.recurso.model.TipoRecurso;

public record TipoRecursoResponse(Long id, String nombre, String unidadMedida) {

	public static TipoRecursoResponse from(TipoRecurso tipoRecurso) {
		return new TipoRecursoResponse(tipoRecurso.getId(), tipoRecurso.getNombre(), tipoRecurso.getUnidadMedida());
	}
}
