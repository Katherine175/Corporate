package com.luxury.recurso.dto;

import jakarta.validation.constraints.NotBlank;

public record TipoRecursoRequest(
		@NotBlank String nombre,
		@NotBlank String unidadMedida) {
}
