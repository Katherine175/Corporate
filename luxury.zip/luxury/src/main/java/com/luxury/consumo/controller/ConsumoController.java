package com.luxury.consumo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.luxury.consumo.dto.ConsumoForm;
import com.luxury.consumo.dto.ConsumoRequest;
import com.luxury.consumo.service.ConsumoService;
import com.luxury.recurso.service.TipoRecursoService;
import com.luxury.sede.service.SedeService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/consumos")
public class ConsumoController {

	private final ConsumoService consumoService;
	private final SedeService sedeService;
	private final TipoRecursoService tipoRecursoService;

	public ConsumoController(ConsumoService consumoService, SedeService sedeService, TipoRecursoService tipoRecursoService) {
		this.consumoService = consumoService;
		this.sedeService = sedeService;
		this.tipoRecursoService = tipoRecursoService;
	}

	@GetMapping
	public String listar(Model model) {
		model.addAttribute("consumos", consumoService.listar());
		return "consumos/lista";
	}

	@GetMapping("/{id}")
	public String obtener(@PathVariable Long id, Model model) {
		model.addAttribute("consumo", consumoService.obtener(id));
		return "consumos/detalle";
	}

	@GetMapping("/sede/{idSede}")
	public String listarPorSede(@PathVariable Long idSede, Model model) {
		model.addAttribute("consumos", consumoService.listarPorSede(idSede));
		return "consumos/lista";
	}

	@GetMapping("/periodo/{periodo}")
	public String listarPorPeriodo(@PathVariable String periodo, Model model) {
		model.addAttribute("consumos", consumoService.listarPorPeriodo(periodo));
		return "consumos/lista";
	}

	@GetMapping("/registrar")
	public String mostrarFormulario(Model model) {
		agregarCatalogos(model);
		model.addAttribute("consumoForm", new ConsumoForm());
		return "consumos/formulario";
	}

	@PostMapping("/registrar")
	public String registrar(
			@Valid @ModelAttribute("consumoForm") ConsumoForm formulario,
			BindingResult bindingResult,
			Model model,
			RedirectAttributes redirectAttributes) {
		if (bindingResult.hasErrors()) {
			agregarCatalogos(model);
			return "consumos/formulario";
		}
		ConsumoRequest request = formulario.toRequest();
		Long consumoId = consumoService.registrar(request).id();
		redirectAttributes.addFlashAttribute("successMessage", "Consumo registrado correctamente.");
		return "redirect:/consumos/" + consumoId;
	}

	private void agregarCatalogos(Model model) {
		model.addAttribute("sedes", sedeService.listar());
		model.addAttribute("tiposRecurso", tipoRecursoService.listar());
	}
}
