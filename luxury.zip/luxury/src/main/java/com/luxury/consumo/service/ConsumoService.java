package com.luxury.consumo.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.alerta.service.ReglasAlertasService;
import com.luxury.auditoria.service.AuditoriaService;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.consumo.dto.ConsumoRequest;
import com.luxury.consumo.dto.ConsumoResponse;
import com.luxury.consumo.model.Consumo;
import com.luxury.consumo.repository.ConsumoRepository;
import com.luxury.finanzas.model.ConsumoCosto;
import com.luxury.finanzas.service.ConversionFinancieraService;
import com.luxury.recurso.service.TipoRecursoService;
import com.luxury.security.service.AuthenticatedUserService;
import com.luxury.sede.service.SedeService;
import com.luxury.tarifa.model.TarifaRecurso;
import com.luxury.tarifa.service.TarifaService;
import com.luxury.usuario.model.Usuario;

@Service
public class ConsumoService {

	private final ConsumoRepository consumoRepository;
	private final SedeService sedeService;
	private final TipoRecursoService tipoRecursoService;
	private final TarifaService tarifaService;
	private final ConversionFinancieraService conversionFinancieraService;
	private final ReglasAlertasService reglasAlertasService;
	private final AuditoriaService auditoriaService;
	private final AuthenticatedUserService authenticatedUserService;

	public ConsumoService(
			ConsumoRepository consumoRepository,
			SedeService sedeService,
			TipoRecursoService tipoRecursoService,
			TarifaService tarifaService,
			ConversionFinancieraService conversionFinancieraService,
			ReglasAlertasService reglasAlertasService,
			AuditoriaService auditoriaService,
			AuthenticatedUserService authenticatedUserService) {
		this.consumoRepository = consumoRepository;
		this.sedeService = sedeService;
		this.tipoRecursoService = tipoRecursoService;
		this.tarifaService = tarifaService;
		this.conversionFinancieraService = conversionFinancieraService;
		this.reglasAlertasService = reglasAlertasService;
		this.auditoriaService = auditoriaService;
		this.authenticatedUserService = authenticatedUserService;
	}

	@Transactional
	public ConsumoResponse registrar(ConsumoRequest request) {
		Usuario usuario = authenticatedUserService.actual();
		TarifaRecurso tarifa = tarifaService.buscarVigente(request.sedeId(), request.tipoRecursoId(), request.fechaConsumo());
		Consumo consumo = new Consumo();
		consumo.setSede(sedeService.buscar(request.sedeId()));
		consumo.setTipoRecurso(tipoRecursoService.buscar(request.tipoRecursoId()));
		consumo.setTarifa(tarifa);
		consumo.setUsuarioRegistro(usuario);
		consumo.setCantidadConsumida(request.cantidadConsumida());
		consumo.setFechaConsumo(request.fechaConsumo());
		consumo.setPeriodo(request.periodo());
		Consumo saved = consumoRepository.save(consumo);
		BigDecimal costoPen = request.cantidadConsumida()
				.multiply(tarifa.getPrecioUnitarioPen())
				.setScale(4, RoundingMode.HALF_UP);
		List<ConsumoCosto> costos = conversionFinancieraService.calcularYGuardarCostos(saved, costoPen);
		reglasAlertasService.evaluarYGenerar(saved, costoPen);
		auditoriaService.registrar(usuario, "CONSUMOS", "CREAR", "consumos", saved.getId(),
				"Registro de consumo para sede " + saved.getSede().getNombre());
		return ConsumoResponse.from(saved, costos);
	}

	@Transactional(readOnly = true)
	public List<ConsumoResponse> listar() {
		return consumoRepository.findAll().stream().map(this::toResponse).toList();
	}

	@Transactional(readOnly = true)
	public ConsumoResponse obtener(Long id) {
		return toResponse(buscar(id));
	}

	@Transactional(readOnly = true)
	public List<ConsumoResponse> listarPorSede(Long sedeId) {
		return consumoRepository.findBySedeId(sedeId).stream().map(this::toResponse).toList();
	}

	@Transactional(readOnly = true)
	public List<ConsumoResponse> listarPorPeriodo(String periodo) {
		return consumoRepository.findByPeriodo(periodo).stream().map(this::toResponse).toList();
	}

	private Consumo buscar(Long id) {
		return consumoRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Consumo no encontrado"));
	}

	private ConsumoResponse toResponse(Consumo consumo) {
		return ConsumoResponse.from(consumo, conversionFinancieraService.listarCostos(consumo.getId()));
	}
}
