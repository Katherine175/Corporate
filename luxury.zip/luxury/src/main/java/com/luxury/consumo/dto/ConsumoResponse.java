package com.luxury.consumo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.luxury.consumo.model.Consumo;
import com.luxury.finanzas.model.ConsumoCosto;

public record ConsumoResponse(
		Long id,
		Long sedeId,
		String sede,
		Long tipoRecursoId,
		String tipoRecurso,
		String unidadMedida,
		BigDecimal cantidadConsumida,
		LocalDate fechaConsumo,
		String periodo,
		LocalDateTime creadoEn,
		List<CostoResponse> costos) {

	public static ConsumoResponse from(Consumo consumo, List<ConsumoCosto> costos) {
		return new ConsumoResponse(
				consumo.getId(),
				consumo.getSede().getId(),
				consumo.getSede().getNombre(),
				consumo.getTipoRecurso().getId(),
				consumo.getTipoRecurso().getNombre(),
				consumo.getTipoRecurso().getUnidadMedida(),
				consumo.getCantidadConsumida(),
				consumo.getFechaConsumo(),
				consumo.getPeriodo(),
				consumo.getCreadoEn(),
				costos.stream().map(CostoResponse::from).toList());
	}
}
