package com.luxury.consumo.dto;

import java.math.BigDecimal;

import com.luxury.finanzas.model.ConsumoCosto;

public record CostoResponse(String moneda, BigDecimal monto, BigDecimal tipoCambioUsado) {

	public static CostoResponse from(ConsumoCosto costo) {
		BigDecimal tipoCambio = costo.getTipoCambio() == null ? null : costo.getTipoCambio().getValor();
		return new CostoResponse(costo.getMoneda().getCodigo(), costo.getMontoCalculado(), tipoCambio);
	}
}
