package com.luxury.consumo.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.luxury.recurso.model.TipoRecurso;
import com.luxury.sede.model.Sede;
import com.luxury.tarifa.model.TarifaRecurso;
import com.luxury.usuario.model.Usuario;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "consumos")
public class Consumo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_consumo")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_sede", nullable = false)
	private Sede sede;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_tipo_recurso", nullable = false)
	private TipoRecurso tipoRecurso;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_tarifa", nullable = false)
	private TarifaRecurso tarifa;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_usuario_registro", nullable = false)
	private Usuario usuarioRegistro;

	@Column(name = "cantidad_consumida", nullable = false, precision = 14, scale = 4)
	private BigDecimal cantidadConsumida;

	@Column(name = "fecha_consumo", nullable = false)
	private LocalDate fechaConsumo;

	@Column(nullable = false, length = 7)
	private String periodo;

	@Column(name = "creado_en", nullable = false)
	private LocalDateTime creadoEn;

	@PrePersist
	void prePersist() {
		if (creadoEn == null) {
			creadoEn = LocalDateTime.now();
		}
	}
}
