package com.luxury.consumo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

public record ConsumoRequest(
		@NotNull Long sedeId,
		@NotNull Long tipoRecursoId,
		@NotNull @Positive BigDecimal cantidadConsumida,
		@NotNull LocalDate fechaConsumo,
		@NotBlank @Pattern(regexp = "\\d{4}-\\d{2}", message = "El periodo debe tener formato yyyy-MM") String periodo) {
}
