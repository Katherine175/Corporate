package com.luxury.consumo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsumoForm {

	@NotNull
	private Long sedeId;

	@NotNull
	private Long tipoRecursoId;

	@NotNull
	@Positive
	private BigDecimal cantidadConsumida;

	@NotNull
	private LocalDate fechaConsumo = LocalDate.now();

	@NotBlank
	@Pattern(regexp = "\\d{4}-\\d{2}", message = "El periodo debe tener formato yyyy-MM")
	private String periodo;

	public ConsumoRequest toRequest() {
		return new ConsumoRequest(sedeId, tipoRecursoId, cantidadConsumida, fechaConsumo, periodo);
	}
}
