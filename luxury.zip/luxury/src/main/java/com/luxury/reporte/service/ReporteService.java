package com.luxury.reporte.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.reporte.dto.ReporteMensualResponse;

import jakarta.persistence.EntityManager;

@Service
public class ReporteService {

	private final EntityManager entityManager;

	public ReporteService(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional(readOnly = true)
	public List<ReporteMensualResponse> mensual(String periodo) {
		return consultaBase("where c.periodo = :periodo", periodo, null);
	}

	@Transactional(readOnly = true)
	public List<ReporteMensualResponse> porSede(Long sedeId) {
		return consultaBase("where c.sede.id = :sedeId", null, sedeId);
	}

	private List<ReporteMensualResponse> consultaBase(String where, String periodo, Long sedeId) {
		var query = entityManager.createQuery("""
				select new com.luxury.reporte.dto.ReporteMensualResponse(
					c.periodo,
					c.sede.nombre,
					c.tipoRecurso.nombre,
					coalesce(sum(c.cantidadConsumida), 0),
					coalesce(sum(case when cc.moneda.codigo = 'PEN' then cc.montoCalculado else 0 end), 0),
					coalesce(sum(case when cc.moneda.codigo = 'USD' then cc.montoCalculado else 0 end), 0),
					coalesce(sum(case when cc.moneda.codigo = 'EUR' then cc.montoCalculado else 0 end), 0)
				)
				from Consumo c
				left join ConsumoCosto cc on cc.consumo = c
				""" + where + """
				group by c.periodo, c.sede.nombre, c.tipoRecurso.nombre
				order by c.periodo, c.sede.nombre, c.tipoRecurso.nombre
				""", ReporteMensualResponse.class);
		if (periodo != null) {
			query.setParameter("periodo", periodo);
		}
		if (sedeId != null) {
			query.setParameter("sedeId", sedeId);
		}
		return query.getResultList();
	}
}
