package com.luxury.reporte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.luxury.reporte.service.ReporteService;

@Controller
@RequestMapping("/reportes")
public class ReporteController {

	private final ReporteService reporteService;

	public ReporteController(ReporteService reporteService) {
		this.reporteService = reporteService;
	}

	@GetMapping("/mensual")
	public String mensual(@RequestParam(required = false) String periodo, Model model) {
		if (periodo != null && !periodo.isBlank()) {
			model.addAttribute("reportes", reporteService.mensual(periodo));
		}
		model.addAttribute("periodo", periodo);
		return "reportes/mensual";
	}

	@GetMapping("/sede/{idSede}")
	public String porSede(@PathVariable Long idSede, Model model) {
		model.addAttribute("reportes", reporteService.porSede(idSede));
		return "reportes/mensual";
	}
}
