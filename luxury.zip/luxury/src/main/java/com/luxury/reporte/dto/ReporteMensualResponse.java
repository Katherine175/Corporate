package com.luxury.reporte.dto;

import java.math.BigDecimal;

public record ReporteMensualResponse(
		String periodo,
		String sede,
		String tipoRecurso,
		BigDecimal totalConsumido,
		BigDecimal costoPen,
		BigDecimal costoUsd,
		BigDecimal costoEur) {
}
