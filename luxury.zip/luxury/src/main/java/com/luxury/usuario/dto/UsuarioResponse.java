package com.luxury.usuario.dto;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.stream.Collectors;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.usuario.model.Usuario;

public record UsuarioResponse(
		Long id,
		String nombre,
		String email,
		EstadoRegistro estado,
		LocalDateTime creadoEn,
		Set<String> roles) {

	public static UsuarioResponse from(Usuario usuario) {
		return new UsuarioResponse(
				usuario.getId(),
				usuario.getNombre(),
				usuario.getEmail(),
				usuario.getEstado(),
				usuario.getCreadoEn(),
				usuario.getUsuarioRoles().stream().map(usuarioRol -> usuarioRol.getRol().getNombre()).collect(Collectors.toSet()));
	}
}
