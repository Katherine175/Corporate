package com.luxury.usuario.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.usuario.dto.UsuarioResponse;
import com.luxury.usuario.model.Usuario;
import com.luxury.usuario.repository.UsuarioRepository;

@Service
public class UsuarioService {

	private final UsuarioRepository usuarioRepository;

	public UsuarioService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	@Transactional(readOnly = true)
	public List<UsuarioResponse> listar() {
		return usuarioRepository.findAll().stream().map(UsuarioResponse::from).toList();
	}

	@Transactional(readOnly = true)
	public UsuarioResponse obtener(Long id) {
		return UsuarioResponse.from(buscar(id));
	}

	public Usuario buscar(Long id) {
		return usuarioRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));
	}
}
