package com.luxury.usuario.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "usuario_roles")
public class UsuarioRol {

	@EmbeddedId
	private UsuarioRolId id = new UsuarioRolId();

	@ManyToOne(fetch = FetchType.LAZY)
	@MapsId("usuarioId")
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;

	@ManyToOne(fetch = FetchType.EAGER)
	@MapsId("rolId")
	@JoinColumn(name = "id_rol")
	private Rol rol;

	public UsuarioRol(Usuario usuario, Rol rol) {
		this.usuario = usuario;
		this.rol = rol;
		this.id = new UsuarioRolId(usuario.getId(), rol.getId());
	}
}
