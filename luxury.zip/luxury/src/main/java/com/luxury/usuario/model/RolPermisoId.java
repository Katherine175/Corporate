package com.luxury.usuario.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Embeddable
public class RolPermisoId implements Serializable {

	@Column(name = "id_rol")
	private Long rolId;

	@Column(name = "id_permiso")
	private Long permisoId;
}
