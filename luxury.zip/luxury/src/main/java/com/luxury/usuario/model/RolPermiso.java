package com.luxury.usuario.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "rol_permisos")
public class RolPermiso {

	@EmbeddedId
	private RolPermisoId id = new RolPermisoId();

	@ManyToOne(fetch = FetchType.LAZY)
	@MapsId("rolId")
	@JoinColumn(name = "id_rol")
	private Rol rol;

	@ManyToOne(fetch = FetchType.EAGER)
	@MapsId("permisoId")
	@JoinColumn(name = "id_permiso")
	private Permiso permiso;

	public RolPermiso(Rol rol, Permiso permiso) {
		this.rol = rol;
		this.permiso = permiso;
		this.id = new RolPermisoId(rol.getId(), permiso.getId());
	}
}
