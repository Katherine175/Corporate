package com.luxury.auth.dto;

import java.util.Set;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record RegisterRequest(
		@NotBlank String nombre,
		@NotBlank @Email String email,
		@NotBlank @Size(min = 6) String password,
		Set<String> roles) {
}
