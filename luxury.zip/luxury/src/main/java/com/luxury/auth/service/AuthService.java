package com.luxury.auth.service;

import java.util.Set;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.auth.dto.RegisterRequest;
import com.luxury.common.exception.BusinessException;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.usuario.model.Rol;
import com.luxury.usuario.model.Usuario;
import com.luxury.usuario.model.UsuarioRol;
import com.luxury.usuario.model.UsuarioRolId;
import com.luxury.usuario.repository.RolRepository;
import com.luxury.usuario.repository.UsuarioRepository;

@Service
public class AuthService {

	private final UsuarioRepository usuarioRepository;
	private final RolRepository rolRepository;
	private final PasswordEncoder passwordEncoder;

	public AuthService(
			UsuarioRepository usuarioRepository,
			RolRepository rolRepository,
			PasswordEncoder passwordEncoder) {
		this.usuarioRepository = usuarioRepository;
		this.rolRepository = rolRepository;
		this.passwordEncoder = passwordEncoder;
	}

	@Transactional
	public void register(RegisterRequest request) {
		if (usuarioRepository.existsByEmail(request.email())) {
			throw new BusinessException("El email ya esta registrado");
		}
		Usuario usuario = new Usuario();
		usuario.setNombre(request.nombre());
		usuario.setEmail(request.email());
		usuario.setPassword(passwordEncoder.encode(request.password()));
		Usuario saved = usuarioRepository.save(usuario);
		Set<String> roles = request.roles() == null || request.roles().isEmpty() ? Set.of("ANALISTA") : request.roles();
		roles.forEach(roleName -> asignarRol(saved, roleName));
	}

	private void asignarRol(Usuario usuario, String roleName) {
		Rol rol = rolRepository.findByNombre(roleName)
				.orElseThrow(() -> new ResourceNotFoundException("Rol no encontrado: " + roleName));
		UsuarioRol usuarioRol = new UsuarioRol();
		usuarioRol.setUsuario(usuario);
		usuarioRol.setRol(rol);
		usuarioRol.setId(new UsuarioRolId(usuario.getId(), rol.getId()));
		usuario.getUsuarioRoles().add(usuarioRol);
	}
}
