package com.luxury.eventoacceso.dto;

import java.time.LocalDateTime;

import com.luxury.common.enums.TipoEventoAcceso;
import com.luxury.eventoacceso.model.EventoAcceso;

public record EventoAccesoResponse(
		Long id,
		Long usuarioId,
		String emailIntentado,
		TipoEventoAcceso tipoEvento,
		String descripcion,
		LocalDateTime fecha,
		String ip) {

	public static EventoAccesoResponse from(EventoAcceso evento) {
		Long usuarioId = evento.getUsuario() == null ? null : evento.getUsuario().getId();
		return new EventoAccesoResponse(
				evento.getId(),
				usuarioId,
				evento.getEmailIntentado(),
				evento.getTipoEvento(),
				evento.getDescripcion(),
				evento.getFecha(),
				evento.getIp());
	}
}
