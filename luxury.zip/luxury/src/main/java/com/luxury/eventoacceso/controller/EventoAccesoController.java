package com.luxury.eventoacceso.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.luxury.eventoacceso.service.EventoAccesoService;

@Controller
@RequestMapping("/eventos-acceso")
public class EventoAccesoController {

	private final EventoAccesoService eventoAccesoService;

	public EventoAccesoController(EventoAccesoService eventoAccesoService) {
		this.eventoAccesoService = eventoAccesoService;
	}

	@GetMapping
	public String listar(Model model) {
		model.addAttribute("eventos", eventoAccesoService.listar());
		return "eventos-acceso/lista";
	}
}
