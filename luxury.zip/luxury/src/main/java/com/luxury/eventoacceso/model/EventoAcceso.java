package com.luxury.eventoacceso.model;

import java.time.LocalDateTime;

import com.luxury.common.enums.TipoEventoAcceso;
import com.luxury.usuario.model.Usuario;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "eventos_acceso")
public class EventoAcceso {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_evento")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;

	@Column(name = "email_intentado", length = 160)
	private String emailIntentado;

	@Enumerated(EnumType.STRING)
	@Column(name = "tipo_evento", nullable = false, length = 40)
	private TipoEventoAcceso tipoEvento;

	@Column(nullable = false, length = 300)
	private String descripcion;

	@Column(nullable = false)
	private LocalDateTime fecha;

	@Column(length = 60)
	private String ip;

	@PrePersist
	void prePersist() {
		if (fecha == null) {
			fecha = LocalDateTime.now();
		}
	}
}
