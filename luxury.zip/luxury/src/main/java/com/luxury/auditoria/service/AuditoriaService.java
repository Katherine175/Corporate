package com.luxury.auditoria.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.auditoria.dto.AuditoriaResponse;
import com.luxury.auditoria.model.Auditoria;
import com.luxury.auditoria.repository.AuditoriaRepository;
import com.luxury.usuario.model.Usuario;

@Service
public class AuditoriaService {

	private final AuditoriaRepository auditoriaRepository;

	public AuditoriaService(AuditoriaRepository auditoriaRepository) {
		this.auditoriaRepository = auditoriaRepository;
	}

	@Transactional
	public void registrar(Usuario usuario, String modulo, String accion, String tabla, Long registroId, String descripcion) {
		Auditoria auditoria = new Auditoria();
		auditoria.setUsuario(usuario);
		auditoria.setModulo(modulo);
		auditoria.setAccion(accion);
		auditoria.setTablaAfectada(tabla);
		auditoria.setIdRegistroAfectado(registroId);
		auditoria.setDescripcion(descripcion);
		auditoriaRepository.save(auditoria);
	}

	@Transactional(readOnly = true)
	public List<AuditoriaResponse> listar() {
		return auditoriaRepository.findAll().stream().map(AuditoriaResponse::from).toList();
	}

	@Transactional(readOnly = true)
	public List<AuditoriaResponse> listarPorUsuario(Long usuarioId) {
		return auditoriaRepository.findByUsuarioId(usuarioId).stream().map(AuditoriaResponse::from).toList();
	}

	@Transactional(readOnly = true)
	public List<AuditoriaResponse> listarPorModulo(String modulo) {
		return auditoriaRepository.findByModuloIgnoreCase(modulo).stream().map(AuditoriaResponse::from).toList();
	}
}
