package com.luxury.auditoria.dto;

import java.time.LocalDateTime;

import com.luxury.auditoria.model.Auditoria;

public record AuditoriaResponse(
		Long id,
		Long usuarioId,
		String usuario,
		String modulo,
		String accion,
		String tablaAfectada,
		Long idRegistroAfectado,
		String descripcion,
		LocalDateTime fecha) {

	public static AuditoriaResponse from(Auditoria auditoria) {
		return new AuditoriaResponse(
				auditoria.getId(),
				auditoria.getUsuario().getId(),
				auditoria.getUsuario().getEmail(),
				auditoria.getModulo(),
				auditoria.getAccion(),
				auditoria.getTablaAfectada(),
				auditoria.getIdRegistroAfectado(),
				auditoria.getDescripcion(),
				auditoria.getFecha());
	}
}
