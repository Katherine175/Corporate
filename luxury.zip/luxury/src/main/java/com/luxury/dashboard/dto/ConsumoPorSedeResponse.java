package com.luxury.dashboard.dto;

import java.math.BigDecimal;

public record ConsumoPorSedeResponse(String sede, BigDecimal totalConsumido) {
}
