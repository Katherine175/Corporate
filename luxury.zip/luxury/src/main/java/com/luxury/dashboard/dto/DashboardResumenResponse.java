package com.luxury.dashboard.dto;

import java.math.BigDecimal;

public record DashboardResumenResponse(
		long totalSedes,
		long totalConsumos,
		long totalAlertas,
		BigDecimal costoTotalPen,
		BigDecimal costoTotalUsd,
		BigDecimal costoTotalEur) {
}
