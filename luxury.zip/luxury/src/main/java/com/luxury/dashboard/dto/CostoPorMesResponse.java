package com.luxury.dashboard.dto;

import java.math.BigDecimal;

public record CostoPorMesResponse(String periodo, String moneda, BigDecimal total) {
}
