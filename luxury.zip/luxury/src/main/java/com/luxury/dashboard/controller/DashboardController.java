package com.luxury.dashboard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.luxury.dashboard.service.DashboardService;

@Controller
@RequestMapping
public class DashboardController {

	private final DashboardService dashboardService;

	public DashboardController(DashboardService dashboardService) {
		this.dashboardService = dashboardService;
	}

	@GetMapping({"/", "/dashboard"})
	public String mostrarDashboard(Model model) {
		model.addAttribute("resumen", dashboardService.resumenGeneral());
		model.addAttribute("consumosPorSede", dashboardService.consumoPorSede());
		model.addAttribute("costosPorMes", dashboardService.costosPorMes());
		return "dashboard/index";
	}
}
