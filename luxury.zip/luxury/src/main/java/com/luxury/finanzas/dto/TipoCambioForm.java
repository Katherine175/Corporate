package com.luxury.finanzas.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TipoCambioForm {

	@NotBlank
	private String monedaOrigen = "PEN";

	@NotBlank
	private String monedaDestino;

	@NotNull
	@Positive
	private BigDecimal valor;

	@NotNull
	private LocalDate fecha = LocalDate.now();

	private EstadoRegistro estado = EstadoRegistro.ACTIVO;

	public TipoCambioRequest toRequest() {
		return new TipoCambioRequest(monedaOrigen, monedaDestino, valor, fecha, estado);
	}
}
