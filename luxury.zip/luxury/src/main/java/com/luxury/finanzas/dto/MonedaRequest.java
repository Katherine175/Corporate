package com.luxury.finanzas.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record MonedaRequest(
		@NotBlank @Size(min = 3, max = 3) String codigo,
		@NotBlank String nombre) {
}
