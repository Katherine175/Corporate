package com.luxury.finanzas.dto;

import com.luxury.finanzas.model.Moneda;

public record MonedaResponse(Long id, String codigo, String nombre) {

	public static MonedaResponse from(Moneda moneda) {
		return new MonedaResponse(moneda.getId(), moneda.getCodigo(), moneda.getNombre());
	}
}
