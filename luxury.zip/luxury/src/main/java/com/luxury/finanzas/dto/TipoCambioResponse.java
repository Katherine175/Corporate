package com.luxury.finanzas.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.finanzas.model.TipoCambio;

public record TipoCambioResponse(
		Long id,
		String monedaOrigen,
		String monedaDestino,
		BigDecimal valor,
		LocalDate fecha,
		EstadoRegistro estado) {

	public static TipoCambioResponse from(TipoCambio tipoCambio) {
		return new TipoCambioResponse(
				tipoCambio.getId(),
				tipoCambio.getMonedaOrigen().getCodigo(),
				tipoCambio.getMonedaDestino().getCodigo(),
				tipoCambio.getValor(),
				tipoCambio.getFecha(),
				tipoCambio.getEstado());
	}
}
