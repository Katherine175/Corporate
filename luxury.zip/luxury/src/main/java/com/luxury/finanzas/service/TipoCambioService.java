package com.luxury.finanzas.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.finanzas.dto.TipoCambioRequest;
import com.luxury.finanzas.dto.TipoCambioResponse;
import com.luxury.finanzas.model.TipoCambio;
import com.luxury.finanzas.repository.TipoCambioRepository;

@Service
public class TipoCambioService {

	private final TipoCambioRepository tipoCambioRepository;
	private final MonedaService monedaService;

	public TipoCambioService(TipoCambioRepository tipoCambioRepository, MonedaService monedaService) {
		this.tipoCambioRepository = tipoCambioRepository;
		this.monedaService = monedaService;
	}

	@Transactional(readOnly = true)
	public List<TipoCambioResponse> listar() {
		return tipoCambioRepository.findAll().stream().map(TipoCambioResponse::from).toList();
	}

	@Transactional
	public TipoCambioResponse crear(TipoCambioRequest request) {
		TipoCambio tipoCambio = new TipoCambio();
		aplicar(tipoCambio, request);
		return TipoCambioResponse.from(tipoCambioRepository.save(tipoCambio));
	}

	@Transactional
	public TipoCambioResponse actualizar(Long id, TipoCambioRequest request) {
		TipoCambio tipoCambio = buscar(id);
		aplicar(tipoCambio, request);
		return TipoCambioResponse.from(tipoCambio);
	}

	public TipoCambio buscar(Long id) {
		return tipoCambioRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Tipo de cambio no encontrado"));
	}

	private void aplicar(TipoCambio tipoCambio, TipoCambioRequest request) {
		tipoCambio.setMonedaOrigen(monedaService.buscarPorCodigo(request.monedaOrigen()));
		tipoCambio.setMonedaDestino(monedaService.buscarPorCodigo(request.monedaDestino()));
		tipoCambio.setValor(request.valor());
		tipoCambio.setFecha(request.fecha());
		tipoCambio.setEstado(request.estado() == null ? EstadoRegistro.ACTIVO : request.estado());
	}
}
