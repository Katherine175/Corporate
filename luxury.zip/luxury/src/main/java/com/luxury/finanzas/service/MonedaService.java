package com.luxury.finanzas.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.finanzas.dto.MonedaRequest;
import com.luxury.finanzas.dto.MonedaResponse;
import com.luxury.finanzas.model.Moneda;
import com.luxury.finanzas.repository.MonedaRepository;

@Service
public class MonedaService {

	private final MonedaRepository monedaRepository;

	public MonedaService(MonedaRepository monedaRepository) {
		this.monedaRepository = monedaRepository;
	}

	@Transactional(readOnly = true)
	public List<MonedaResponse> listar() {
		return monedaRepository.findAll().stream().map(MonedaResponse::from).toList();
	}

	@Transactional
	public MonedaResponse crear(MonedaRequest request) {
		Moneda moneda = new Moneda();
		moneda.setCodigo(request.codigo().toUpperCase());
		moneda.setNombre(request.nombre());
		return MonedaResponse.from(monedaRepository.save(moneda));
	}

	public Moneda buscarPorCodigo(String codigo) {
		return monedaRepository.findByCodigo(codigo.toUpperCase())
				.orElseThrow(() -> new ResourceNotFoundException("Moneda no encontrada: " + codigo));
	}
}
