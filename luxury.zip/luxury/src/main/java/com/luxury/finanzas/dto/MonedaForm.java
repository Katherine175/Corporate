package com.luxury.finanzas.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MonedaForm {

	@NotBlank
	@Size(min = 3, max = 3)
	private String codigo;

	@NotBlank
	private String nombre;

	public MonedaRequest toRequest() {
		return new MonedaRequest(codigo, nombre);
	}
}
