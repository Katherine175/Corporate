package com.luxury.finanzas.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record TipoCambioRequest(
		@NotBlank String monedaOrigen,
		@NotBlank String monedaDestino,
		@NotNull @Positive BigDecimal valor,
		@NotNull LocalDate fecha,
		EstadoRegistro estado) {
}
