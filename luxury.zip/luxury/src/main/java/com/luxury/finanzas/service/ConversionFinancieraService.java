package com.luxury.finanzas.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.consumo.model.Consumo;
import com.luxury.finanzas.model.ConsumoCosto;
import com.luxury.finanzas.model.Moneda;
import com.luxury.finanzas.model.TipoCambio;
import com.luxury.finanzas.repository.ConsumoCostoRepository;
import com.luxury.finanzas.repository.MonedaRepository;
import com.luxury.finanzas.repository.TipoCambioRepository;

@Service
public class ConversionFinancieraService {

	private final ConsumoCostoRepository consumoCostoRepository;
	private final MonedaRepository monedaRepository;
	private final TipoCambioRepository tipoCambioRepository;

	public ConversionFinancieraService(
			ConsumoCostoRepository consumoCostoRepository,
			MonedaRepository monedaRepository,
			TipoCambioRepository tipoCambioRepository) {
		this.consumoCostoRepository = consumoCostoRepository;
		this.monedaRepository = monedaRepository;
		this.tipoCambioRepository = tipoCambioRepository;
	}

	@Transactional
	public List<ConsumoCosto> calcularYGuardarCostos(Consumo consumo, BigDecimal costoPen) {
		Moneda pen = buscarMoneda("PEN");
		List<ConsumoCosto> costos = new ArrayList<>();
		costos.add(crearCosto(consumo, pen, null, costoPen));
		costos.add(convertir(consumo, costoPen, "USD", consumo.getFechaConsumo()));
		costos.add(convertir(consumo, costoPen, "EUR", consumo.getFechaConsumo()));
		return consumoCostoRepository.saveAll(costos);
	}

	@Transactional(readOnly = true)
	public List<ConsumoCosto> listarCostos(Long consumoId) {
		return consumoCostoRepository.findByConsumoId(consumoId);
	}

	private ConsumoCosto convertir(Consumo consumo, BigDecimal costoPen, String monedaDestino, LocalDate fecha) {
		TipoCambio tipoCambio = tipoCambioRepository.findVigente("PEN", monedaDestino, fecha, EstadoRegistro.ACTIVO)
				.orElseThrow(() -> new ResourceNotFoundException("No existe tipo de cambio vigente PEN -> " + monedaDestino));
		BigDecimal monto = costoPen.multiply(tipoCambio.getValor()).setScale(4, RoundingMode.HALF_UP);
		return crearCosto(consumo, tipoCambio.getMonedaDestino(), tipoCambio, monto);
	}

	private ConsumoCosto crearCosto(Consumo consumo, Moneda moneda, TipoCambio tipoCambio, BigDecimal monto) {
		ConsumoCosto costo = new ConsumoCosto();
		costo.setConsumo(consumo);
		costo.setMoneda(moneda);
		costo.setTipoCambio(tipoCambio);
		costo.setMontoCalculado(monto.setScale(4, RoundingMode.HALF_UP));
		return costo;
	}

	private Moneda buscarMoneda(String codigo) {
		return monedaRepository.findByCodigo(codigo)
				.orElseThrow(() -> new ResourceNotFoundException("Moneda no encontrada: " + codigo));
	}
}
