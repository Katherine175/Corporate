package com.luxury.alerta.dto;

import java.time.LocalDateTime;

import com.luxury.alerta.model.Alerta;
import com.luxury.common.enums.EstadoAlerta;
import com.luxury.common.enums.NivelAlerta;
import com.luxury.common.enums.TipoAlerta;

public record AlertaResponse(
		Long id,
		Long consumoId,
		String sede,
		String tipoRecurso,
		TipoAlerta tipoAlerta,
		String mensaje,
		NivelAlerta nivel,
		EstadoAlerta estado,
		LocalDateTime fechaGeneracion) {

	public static AlertaResponse from(Alerta alerta) {
		return new AlertaResponse(
				alerta.getId(),
				alerta.getConsumo().getId(),
				alerta.getConsumo().getSede().getNombre(),
				alerta.getConsumo().getTipoRecurso().getNombre(),
				alerta.getTipoAlerta(),
				alerta.getMensaje(),
				alerta.getNivel(),
				alerta.getEstado(),
				alerta.getFechaGeneracion());
	}
}
