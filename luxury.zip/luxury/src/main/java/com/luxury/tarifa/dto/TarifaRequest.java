package com.luxury.tarifa.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record TarifaRequest(
		@NotNull Long sedeId,
		@NotNull Long tipoRecursoId,
		@NotNull @Positive BigDecimal precioUnitarioPen,
		@NotNull LocalDate fechaInicio,
		LocalDate fechaFin,
		EstadoRegistro estado) {
}
