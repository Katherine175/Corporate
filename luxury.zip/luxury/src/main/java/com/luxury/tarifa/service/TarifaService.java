package com.luxury.tarifa.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.common.exception.ResourceNotFoundException;
import com.luxury.recurso.service.TipoRecursoService;
import com.luxury.sede.service.SedeService;
import com.luxury.tarifa.dto.TarifaRequest;
import com.luxury.tarifa.dto.TarifaResponse;
import com.luxury.tarifa.model.TarifaRecurso;
import com.luxury.tarifa.repository.TarifaRecursoRepository;

@Service
public class TarifaService {

	private final TarifaRecursoRepository tarifaRepository;
	private final SedeService sedeService;
	private final TipoRecursoService tipoRecursoService;

	public TarifaService(TarifaRecursoRepository tarifaRepository, SedeService sedeService, TipoRecursoService tipoRecursoService) {
		this.tarifaRepository = tarifaRepository;
		this.sedeService = sedeService;
		this.tipoRecursoService = tipoRecursoService;
	}

	@Transactional(readOnly = true)
	public List<TarifaResponse> listar() {
		return tarifaRepository.findAll().stream().map(TarifaResponse::from).toList();
	}

	@Transactional
	public TarifaResponse crear(TarifaRequest request) {
		TarifaRecurso tarifa = new TarifaRecurso();
		aplicar(tarifa, request);
		return TarifaResponse.from(tarifaRepository.save(tarifa));
	}

	@Transactional
	public TarifaResponse actualizar(Long id, TarifaRequest request) {
		TarifaRecurso tarifa = buscar(id);
		aplicar(tarifa, request);
		return TarifaResponse.from(tarifa);
	}

	@Transactional(readOnly = true)
	public TarifaResponse obtenerVigente(Long sedeId, Long tipoRecursoId) {
		return TarifaResponse.from(buscarVigente(sedeId, tipoRecursoId, LocalDate.now()));
	}

	public TarifaRecurso buscar(Long id) {
		return tarifaRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Tarifa no encontrada"));
	}

	public TarifaRecurso buscarVigente(Long sedeId, Long tipoRecursoId, LocalDate fecha) {
		return tarifaRepository.findVigente(sedeId, tipoRecursoId, fecha, EstadoRegistro.ACTIVO)
				.orElseThrow(() -> new ResourceNotFoundException("No existe tarifa vigente para la sede y recurso"));
	}

	private void aplicar(TarifaRecurso tarifa, TarifaRequest request) {
		tarifa.setSede(sedeService.buscar(request.sedeId()));
		tarifa.setTipoRecurso(tipoRecursoService.buscar(request.tipoRecursoId()));
		tarifa.setPrecioUnitarioPen(request.precioUnitarioPen());
		tarifa.setFechaInicio(request.fechaInicio());
		tarifa.setFechaFin(request.fechaFin());
		tarifa.setEstado(request.estado() == null ? EstadoRegistro.ACTIVO : request.estado());
	}
}
