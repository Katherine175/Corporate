package com.luxury.tarifa.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.luxury.common.enums.EstadoRegistro;
import com.luxury.tarifa.model.TarifaRecurso;

public record TarifaResponse(
		Long id,
		Long sedeId,
		String sede,
		Long tipoRecursoId,
		String tipoRecurso,
		BigDecimal precioUnitarioPen,
		LocalDate fechaInicio,
		LocalDate fechaFin,
		EstadoRegistro estado) {

	public static TarifaResponse from(TarifaRecurso tarifa) {
		return new TarifaResponse(
				tarifa.getId(),
				tarifa.getSede().getId(),
				tarifa.getSede().getNombre(),
				tarifa.getTipoRecurso().getId(),
				tarifa.getTipoRecurso().getNombre(),
				tarifa.getPrecioUnitarioPen(),
				tarifa.getFechaInicio(),
				tarifa.getFechaFin(),
				tarifa.getEstado());
	}
}
